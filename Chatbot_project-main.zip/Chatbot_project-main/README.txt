EduBot - College Query Chatbot

Steps to Run:
1. Install requirements:
   pip install flask

2. Run the app:
   python app.py

3. Open browser and go to:
   http://127.0.0.1:5000/

Now you can chat with EduBot!
